package comm.Dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import com.emtity.addmediation;

public class addmediationdao {

	private Connection conn;

	public addmediationdao(Connection conn) {
		super();
		this.conn = conn;
	}
	
	
	public boolean insertmediation(addmediation M) {
		boolean f = false;
		
		
		try {
			
			
			
			PreparedStatement ps=conn.prepareStatement("INSERT INTO medical(adnumber,gender,age,mediation)VALUES(?,?,?,?)");
			
			ps.setString(1, M.getAdnumber());
			ps.setString(2, M.getGender());
			ps.setString(3, M.getAge());
			ps.setString(4, M.getMediation());
			
			int i = ps.executeUpdate();
      
			if (i == 1) {
				return true;
			}
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		
		return f;
		
		
	}
}
