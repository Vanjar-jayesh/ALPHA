package com.doctor.servlet;

import java.io.IOException;

import com.db.DBConnect;
import com.emtity.addmediation;
import com.mysql.cj.x.protobuf.MysqlxPrepare.Prepare.Builder;

import comm.Dao.addmediationdao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("mediationservlet")
public class mediationservlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		
		
		try {
			
			
			String adnumber = req.getParameter("Adnumber");
			String gender = req.getParameter("gender");
			String age = req.getParameter("age");
			String mediaction = req.getParameter("mediation");
			
			addmediation m = new addmediation(adnumber, gender, mediaction, age);
			
			addmediationdao dao = new addmediationdao(DBConnect.getconn());
			
			HttpSession session = req.getSession();
			
			
			if (dao.insertmediation(m)) {
				
				session.setAttribute("succMsg", "mediation Addes Sucessfully..");
				resp.sendRedirect("Doctor/medical.jsp");
				
			}else {
				

				session.setAttribute("errorMsg", "mediation not Addes Sucessfully..");
				resp.sendRedirect("Doctor/medical.jsp");
			}
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		
	}
}
