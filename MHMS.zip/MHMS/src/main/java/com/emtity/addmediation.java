package com.emtity;

public class addmediation {

	private int id;
	private String adnumber;
	private String gender;
	private String age;
	private String mediation;
	public addmediation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public addmediation(String adnumber, String gender, String mediation,String age) {
		super();
		this.adnumber = adnumber;
		this.gender = gender;
		this.age = age;
		this.mediation = mediation;
	}
	public addmediation(int id, String adnumber, String gender, String mediation,String age) {
		super();
		this.id = id;
		this.adnumber = adnumber;
		this.gender = gender;
		this.age = age;
		this.mediation = mediation;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdnumber() {
		return adnumber;
	}
	public void setAdnumber(String adnumber) {
		this.adnumber = adnumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMediation() {
		return mediation;
	}
	public void setMediation(String mediation) {
		this.mediation = mediation;
	}
	
	
	
	


}
